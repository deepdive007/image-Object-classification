
# coding: utf-8

# In[1]:
#importing all necesary packages

import pandas as pd
import os, sys, csv
import glob, errno
import numpy as np
import cv2
import copy
import math


# In[2]:

# reading csv file

# parameter : 
#                      filename : name of csv file

# returned variable : 
#                     df : dataframe containing information of all boxes cordinates and respective class label 

def read_csv_file(filename):
    print(os.getcwd())
    csv_file=pd.read_csv(filename, header =None)
    df=pd.DataFrame(csv_file)
    df.columns=df.iloc[0]
    df=df.drop(df.index[0])
    return df


# In[3]:

# normalizing the image box co-ordinates to the providing input image size i.e,:input size to architecture

# parameter :
#            image_rect_dict  : list that containing boxes info for each image of original size,
#            input_size       : size of input image to architecture

# return variable:
#                normalized_image_rect_dict : list that containing boxes info for each image of normalized size that is input to our yolo architecture

def normalizing_image(image_rect_dict, input_size):
    normal_height = input_size[0]
    normal_width = input_size[1]
    normalized_image_rect_dict=[]
    for document in image_rect_dict:
        
        image=document[0]
        image_info=document[1]
        shape_of_Doc = document[1][0]
        rect_info = document[1][1]
        x_factor=normal_width/(document[1][0][1])
        y_factor=normal_height/(document[1][0][0])
        document[1][0][0] = normal_height
        document[1][0][1] = normal_width
        for rect_instance_no in  range(len(document[1][1])):
            
            document[1][1][rect_instance_no][0][0] = document[1][1][rect_instance_no][0][0]*x_factor
            document[1][1][rect_instance_no][0][1] = document[1][1][rect_instance_no][0][1]*y_factor
            
            document[1][1][rect_instance_no][1][0] = document[1][1][rect_instance_no][1][0]*x_factor
            document[1][1][rect_instance_no][1][1] = document[1][1][rect_instance_no][1][1]*y_factor
            
        normalized_image_rect_dict.append(document)
    return normalized_image_rect_dict


# In[4]:

# creating grids for input image 

# parameter :
#            no_of_grid          :  no of grid in each axis (Y, X)
#            input_image_size    :  size of input image to architecture

# return variable:
#                list_of_grid_corner   :  list of grid corners (top_left, bottom_right)
#                size_of_grid          :  size of grid :(height, width)   


def create_grid(no_of_grid, input_image_size):
    size_of_grid = (int(input_image_size[0]/no_of_grid[0]), int(input_image_size[1]/no_of_grid[1] ))    #(height, width)
    list_of_grid_corner=[]
    residual_length = input_image_size[0]
    
    for row in range(no_of_grid[0]):
        bottom_right_y = 0
        
        if  residual_length >= size_of_grid[0]:
            bottom_right_y = size_of_grid[0] * (row + 1) 
        else:
            bottom_right_y = size_of_grid[0] * (row) + residual_length 
        
        residual_length = residual_length - size_of_grid[0]
        residual_width = input_image_size[1]
        row_grid=[]
        
        for col in range(no_of_grid[1]):
            bottom_right_x = 0
            
            if  residual_width >= size_of_grid[1]:
                bottom_right_x = size_of_grid[1] * (col + 1) 
            else:
                bottom_right_y = size_of_grid[1] * (col) + residual_width 
            residual_width = residual_width - size_of_grid[1]
            top_left_y = size_of_grid[0] * row
            top_left_x = size_of_grid[1] * col
            row_grid.append([(top_left_x, top_left_y), (bottom_right_x, bottom_right_y)])
            
        list_of_grid_corner.append(row_grid)
     #   print("size_of_grid = ",size_of_grid)
        
    return list_of_grid_corner, size_of_grid         
    


# In[5]:

# checking instance or box mid point (x, y) falling in grid or not

# parameter :
#            instance          :  Box having info for (x,y,w,h) for box and object presence(p(c)), one hot vector for class label
#            grid              :  top_left and bottom_right of grid

# return variable: boolean value
#                 return True      :   if grid have box
#                 return False     :   if grid do not have  box
#

def isinstance_in_grid(instance, grid):

    mid_point_x = (instance[0][0] + instance[1][0])/2
    mid_point_y = (instance[0][1] + instance[1][1])/2
    
    if (mid_point_x > grid[0][0] and mid_point_x <= grid[1][0]) and (mid_point_y > grid[0][1] and mid_point_y <= grid[1][1]):
        return True
    else:
        return False
    

    
    

# In[17]:

# identifying the class of instance

# parameter :
#            instance_class          :   class name : e.g. 'paragraph'
#            no_of_class             :   nmber of class possible

# return variable: 
#                 one_hot_class_vector      :   one hot encoding of class label of size (1, no_of_class)


def identify_class(instance_class,no_of_class):
    #print("instance_class = ",instance_class)
    one_hot_class_vector= np.zeros((no_of_class,), dtype=int)
    class_list = ["heading", "paragraph", "table", "list", "image"]
    if instance_class != "":
        class_index = class_list.index(instance_class)
        one_hot_class_vector[class_index] = 1

    return one_hot_class_vector


# In[6]:

# creating label for each anchor box

# parameter :
#            instance                   :   instance that has to be labelled
#            flag                       :   true: if instance in grid else false
#            no_of_class                :   nmber of class possible
#            label_training_instance    :   list that can include label : not seem to be used 
#            grid_size                  :   grid height and width

# return variable: 
#                 label                 :    label of size (1, no_of_class)


def create_label_for_grid(instance, flag, no_of_class, label_training_instance, grid_size):
    object_presence=0
    label = np.zeros((5+no_of_class,), dtype = float)
    if flag == True and instance[4]!= "":
        object_presence = 1
        one_hot_class_vector = identify_class(instance[4], no_of_class)
        label[0] = instance[0]
        label[1] = instance[1]
        label[2] = instance[2]#width
        label[3] = instance[0]#height
        label[4] = object_presence
        label[5:] = one_hot_class_vector

    return label
        


# In[7]:

# calculating the overlapping co-ordinates of 2 boxes

# parameter :
#            interval_a          :   first box min, max
#            interval_b          :   second box min, max

# return variable: 
#                 intersecting length of segment


def interval_overlap(interval_a, interval_b):
    x1, x2 = interval_a
    x3, x4 = interval_b

    if x3 < x1:
        if x4 < x1:
            return 0
        else:
            return min(x2,x4) - x1
    else:
        if x2 < x3:
            return 0
        else:
            return min(x2,x4) - x3  


# In[8]:

# calculating the IOU's of 2 boxes

# parameter :
#            box1          :   first box configuration
#            box2          :   second box configuration

# return variable  :  IOU of boxes

def bbox_iou(box1, box2):
    x1_min  = box1[0] - box1[2]/2
    x1_max  = box1[0] + box1[2]/2
    y1_min  = box1[1] - box1[3]/2
    y1_max  = box1[1] + box1[3]/2
    
    x2_min  = box2[0] - box2[2]/2
    x2_max  = box2[0] + box2[2]/2
    y2_min  = box2[1] - box2[3]/2
    y2_max  = box2[1] + box2[3]/2
    
    intersect_w = interval_overlap([x1_min, x1_max], [x2_min, x2_max])
    intersect_h = interval_overlap([y1_min, y1_max], [y2_min, y2_max])
    
    intersect = intersect_w * intersect_h
    
    union = box1[2] * box1[3] + box2[2] * box2[3] - intersect
    
    return float(intersect) / union


# In[9]:

# calculating the IOU'with true box in order to assign best anchor box to object at training time

# parameter :
#            instance          :   instance configuration
#            anchor_w          :   anchor width
#            anchor_h          :   anchor height


# return variable  :  
#                    iou      :    IOU of anchor_box with instance


def calculate_iou_with_true_box(instance, anchor_w, anchor_h):

    instance_cord = [0, 0, instance[0], instance[1]]
    anchor_cord = [0, 0, anchor_w, anchor_h]
    iou = bbox_iou(instance_cord, anchor_cord)
    return iou
    


# In[10]:

# global_variable :
#                  ANCHORS      :   contain information of width and height of respective anchor box
#                 len(ANCHORS)  :  2 * no_of_anchor_box
#                 first anchor_box width, height  i :0 = ANCHOR[2 * i], ANCHOR[2*i + 1] and so on....

ANCHORS = [1.90603223, 0.14906887, 5.53059165, 0.74886134]  # anchor configuration



# finding best anchor to assign a object
# parameter  :
#              instance               :   instance configuration

# return variable  :  
#                    best_anchor      :    index of best anchor

def find_best_anchor_box(instance):
    best_anchor = -1
    max_iou     = -1
    
    for i in range(len(ANCHORS)//2):
      
        anchor_w=ANCHORS[2*i]
        anchor_h=ANCHORS[2*i + 1]
  
        iou = calculate_iou_with_true_box(instance[2:4], anchor_w, anchor_h)
    
        if max_iou < iou:
            best_anchor = i
            max_iou= iou
    return best_anchor    
    


# In[11]:

# finding best anchor to assign a object
# parameter  :
#              no_of_grid             :   no of grid in image in each direction (Y, X)
#              input_image_size       :   input image size to the architecture
#              instance               :   instance that have to be normalized
#              grid_size              :   size of each grid in dimension (Y, X)

# return variable  :  
#                    box      :    list of normalized cordinate, width and height relative to grid

def normalize_instance_relative_to_grid(no_of_grid, input_image_size, instance, grid_size):

    center_x = 0.5*no_of_grid[1]*(instance[0][0] + instance[1][0])/input_image_size[1]
    center_y = 0.5*no_of_grid[0]*(instance[0][1] + instance[1][1])/input_image_size[0]

    center_w = no_of_grid[1]*abs(instance[0][0] - instance[1][0])/input_image_size[1]
    center_h = no_of_grid[0]*abs(instance[0][1] - instance[1][1])/input_image_size[0]

    x =  (instance[0][0] + instance[1][0])/2
    y =  (instance[0][1] + instance[1][1])/2
    w = abs(instance[0][0] - instance[1][0])/grid_size[1]
    h = abs(instance[0][1] - instance[1][1])/grid_size[0]
 
    box = [center_x, center_y, w, h, instance[2]]

    return box


# In[12]:

# mapping each object to respective grid

# parameter  :
#              normalized_image_rect_dict    :    normalized list of cordinate w.r.t. input image size for each image
#              list_of_grid_corner           :    list of grids cordinates (top_left, bottom_right)
#              grid_size                     :    size of each grid in dimension (Y, X)
#              no_of_class                   :    no of possible class(here it is 5)
#              no_of_anchor_box              :    no of anchor box defined for each grid (here it is 2)
#              input_image_size              :    size of input image that is input to yolo architecture
#              no_of_grid                    :    no of grid in any image 



# return variable  :   
#                    instance_x      :    numpy array of all normlaized image of shape:
#                                         ( #_of_input_image, height_of_image, width_of_image , #_of_channel )
#                                         ( 69, 512, 512, 3 )

#                    instance_y      :    numpy array of label instance for each normlaized image of shape:
#                                         ( #_of_input_image, no_of_grid_row, no_of_grid_col, no_of_anchor_box, label_of_each_anchor)
#                                         ( 69, 8, 8, 2, 10 )


#                    true_boxes      :    numpy array of true boxes in any image having max size of 50 each have [x, y, w, h]

def map_each_object_t_grid(normalized_image_rect_dict, list_of_grid_corner, grid_size, no_of_class, no_of_anchor_box, input_image_size, no_of_grid ):
    label_training_set_Y = [] 
    label_training_set_X = []
    true_boxes = np.zeros((len(normalized_image_rect_dict),1, 1, 1, 50, 4 )) # maximum object any image can have


    for image_index in range(len(normalized_image_rect_dict)):
        image_name = cv2.imread(normalized_image_rect_dict[image_index][0])
        resize_image = cv2.resize(image_name, (input_image_size[1],input_image_size[0]))#check for imahe size 1 IS HEIGHT, 0 IS WIDTH
        label_training_set_X.append(resize_image/255)
        total_tru=0;# to check how many rect are there in any image 
       
        label_training_instance = []
       
        for row_grid_list in list_of_grid_corner:
        #    print("this is for row -------------------------------------------")
            label_training_instance_row = []
            for grid in row_grid_list:
            #    print("this is for grid in row++++++++++++++++++++++++++++")
                label_list=[None]*no_of_anchor_box
                grid_label=[]
                true_content = 0 # to check for eah anchor
                
                for instance in range(len(normalized_image_rect_dict[image_index][1][1])):
                    flag = isinstance_in_grid(normalized_image_rect_dict[image_index][1][1][instance], grid)
                    if flag == True:                    
                        #############################instance is in grid, now find best suitable anchor box for it
                        normalized_instance = normalize_instance_relative_to_grid(no_of_grid, input_image_size, normalized_image_rect_dict[image_index][1][1][instance], grid_size)
                     
                        best_anchor_index = find_best_anchor_box(normalized_instance) # give best anchor
                        if label_list[best_anchor_index] is not None:  # if best anchor is not available then assign another
                            best_anchor_index=1-best_anchor_index
                    
                        if label_list[best_anchor_index] is None and true_content< no_of_anchor_box: # anchor is available in list and all anchor is not filled 
                         
                            label = create_label_for_grid(normalized_instance, flag, no_of_class, label_training_instance, grid_size)
                           
                            label_list[best_anchor_index] = label # created label is assigned to best anchor
                         
                            true_boxes[image_index,0,0,0,total_tru] = label[:4]  # cordinates of label assgined to true box
                       
                            true_content = true_content + 1 # to check how many anchor filled 
                           
                            total_tru =total_tru+1
                
                        elif true_content < no_of_anchor_box: # when only one rect second anchor  is empty  # this time not seems to be used
                            
                           
                            zero_instance =[0,0,0,0,""] 
                            label = create_label_for_grid(zero_instance, flag, no_of_class, label_training_instance, grid_size)
                          
                            label_list[best_anchor_index] = label
                       
                            true_content = true_content + 1
                        
           
                zero_instance =[0,0,0,0,""]  # for all grid which do not have rect
                label = create_label_for_grid(zero_instance, flag, no_of_class, label_training_instance, grid_size)
              
             
                for anchor_label in range(len(label_list)):
                    if label_list[anchor_label] is None:
                        label_list[anchor_label] = label
                        true_content = true_content + 1
                       
                grid_label.append(list(label_list[0]))
                grid_label.append(list(label_list[1]))
                
            
                label_training_instance_row.append(grid_label)
                
            label_training_instance.append(label_training_instance_row)
   
       
  
        label_training_set_Y.append(label_training_instance)
    
   
    instance_y = np.asarray(label_training_set_Y)                
    instance_x = np.asarray(label_training_set_X)
    
    return instance_x, instance_y, true_boxes

        
    


# In[13]:


# verify the train.csv have all object correct.


# parameter  :
#              image_folder               :   folder that contain all training images
#              image_rect_dict            :   list that contain info for all object in each image



def image_rect_printing(image_folder, image_rect_dict):

    path = os.getcwd()
    
    os.chdir(r'/home/bitnami/vikrant/deep_version/rectangled_set')

    for image in image_rect_dict:

        Image = cv2.imread(image_folder+"/"+image[0])
        cv2.imwrite(image[0],Image)
        for rect in image[1][1]:

            cv2.rectangle(Image, tuple(rect[0]), tuple(rect[1]), (0,255,0), 3)
        cv2.imwrite(image[0], Image)
    os.chdir(path)

    
    

# In[122]:


# verify the training_code have all object correct after normalizing input image and thier objects.


# parameter  :
#              image_folder               :   folder that contain all training images
#              image_rect_dict            :   list that contain info for all object in each image
#              input_image_size           :   size of input image that will be input to yolo architecture



def image_norm_rect_printing(image_folder, image_rect_dict, input_image_size):

    path = os.getcwd()
    
    os.chdir(r'/home/bitnami/vikrant/deep_version/rectangled_set/normalized')

    for image in image_rect_dict:

        Image = cv2.imread(image_folder+"/"+image[0])
        Image = cv2.resize(Image, (input_image_size[0], input_image_size[1])) 
        cv2.imwrite(image[0],Image)
        for rect in image[1][1]:

            cv2.rectangle(Image, (int(rect[0][0]),int(rect[0][1])), (int(rect[1][0]),int(rect[1][1])), (0,255,0), 3)
        cv2.imwrite(image[0], Image)
    os.chdir(path)


# In[123]:



# used in kmeans to find the similarities b/w  instance and centroids


# parameter  :
#              data_instance           :   instances having ( w, h ) of anchor_box
#              centroids               :   centroids of cluster


# return variable  :  
#                    similarities      :    similarity b/w centroid and data_instance



def IOU(data_instance, centroids):
    w, h = data_instance
    similarities = []

    for centroid in centroids:
        c_w, c_h = centroid

        if c_w >= w and c_h >= h:
            similarity = w*h/(c_w*c_h)
        elif c_w >= w and c_h <= h:
            similarity = w*c_h/(w*h + (c_w-w)*c_h)
        elif c_w <= w and c_h >= h:
            similarity = c_w*h/(w*h + c_w*(c_h-h))
        else: #means both w,h are bigger than c_w and c_h respectively
            similarity = (c_w*c_h)/(w*h)
        similarities.append(similarity) # will become (k,) shape

    return np.array(similarities)


# In[128]:


# kmeans used to return anchor box (w, h) for each anchor box 


# parameter  :
#              kmean_data_instance            :   list of all object width and height (w, h)
#              no_of_anchor_box               :   total no of anchor box 


# return variable  :  
#                    centroids      :    return (w, h) for each anchor box 




import random
def run_kmean(kmean_data_instance,no_of_anchor_box ):
    no_instances = kmean_data_instance.shape[0]
    iterations = 0
    prev_assignments = np.ones(no_instances)*(-1)
    iteration = 0
    old_distances = np.zeros((no_instances, no_of_anchor_box))

    indices = [random.randrange(kmean_data_instance.shape[0]) for i in range(no_of_anchor_box)]
    centroids = kmean_data_instance[indices]
    anchor_dimesion = kmean_data_instance.shape[1]
    ###########################
    while True:
        distances = []
        iteration += 1
        for i in range(no_instances):
            d = 1 - IOU(kmean_data_instance[i], centroids)
            distances.append(d)
        distances = np.asarray(distances) # distances.shape = ( no_instances, no_of_anchor_box)

       # print("iteration {}: dists = {}".format(iteration, np.sum(np.abs(old_distances-distances))))

        #assign samples to centroids
        assignments = np.argmin(distances,axis=1)

        if (assignments == prev_assignments).all() :
            return centroids

        #calculate new centroids
        centroid_sums=np.zeros((no_of_anchor_box, anchor_dimesion), np.float)
        for i in range(no_instances):
            centroid_sums[assignments[i]]+=kmean_data_instance[i]
        for j in range(no_of_anchor_box):
            centroids[j] = centroid_sums[j]/(np.sum(assignments==j) + 1e-6)

        prev_assignments = assignments.copy()
        old_distances = distances.copy()    
    return centroids
    
    


# In[129]:


# creating anchor_box configuration


# parameter  :
#              normalized_image_rect_dict            :   list of all object for each image which is normalized based on input_image
#              no_of_anchor_box               :   total no of anchor box 
#              no_of_grid               :   no of grid_row and grid col : here it is (8,8) 
#              input_image_size               :   size of input image that is input to yolo architecture 

# return variable  :  
#                    centroids      :    return (w, h) for each anchor box 



def create_anchor_box(normalized_image_rect_dict, no_of_anchor_box, no_of_grid, input_image_size):
 #   print("no_of_anchor_box = ",no_of_anchor_box)
 #   print("len(normalized_image_rect_dict) =", len(normalized_image_rect_dict))
 #   print("no_of_grid = ",no_of_grid)
 #   print("input_image_size = ", input_image_size)
 #   no_of_image = len(normalized_image_rect_dict)
    cell_w = input_image_size[1]/ no_of_grid[1]
    cell_h = input_image_size[0]/ no_of_grid[0]
    count = 0
    total_rect_wh_in_dataset = []
    for image in  normalized_image_rect_dict:
        image_name = image[0]
       # print("image_name",image_name)
        total_rect_in_image = len(image[1][1])
        count = count +  total_rect_in_image
      #  print("total_rect_in_image ",image_name, total_rect_in_image)
        #print("\n\n")
        for rect in image[1][1]:
            top_left  = rect[0]
            bottom_right = rect[1]
            rect_class = rect[2]
            #print("top, bottom, class = ",top_left,bottom_right, rect_class )
            relative_w = float(abs(bottom_right[0] - top_left[0])/cell_w)
            relative_h = float(abs(bottom_right[1] - top_left[1])/cell_h)
            #print("w ", abs(bottom_right[0] - top_left[0]))
           # print("h ", abs(bottom_right[1] - top_left[1]))
            
            total_rect_wh_in_dataset.append(tuple((relative_w, relative_h)))
            
  #  print("count = ",count)
   # print("len(total_rect_wh_in_dataset) = ",len(total_rect_wh_in_dataset))
    kmean_data_instance = np.asarray(total_rect_wh_in_dataset)
   # print("kmean_datainstance.shape ",kmean_data_instance.shape )
    centroids = run_kmean(kmean_data_instance,no_of_anchor_box )
    print("centroids = ",centroids)
    return centroids
    


# In[130]:



# creating training set

# parameter used in create_train_set function of trainingset_yolo_1

# path = path of file trainingset_yolo_1.py or working directory
# file = csv file having info regarding rectangles and thier cordinate in an image
# image_folder = path of data images
# input_image_size =  image size that will be input to yolo architecture 
# no_of_grid =  Number of grid that a image can have.
# no_of_class = Number of class that has to be identified
# no_of_anchor_box = Number of maximum objects that can be detected by  a single grid

# returned variables 

# train_x = contain all images of size input_image_size: size of train_x is: 
#                (# of instances, image_height, image_width, # of channel) : (69, 512, 512, 3)
                
# train_y = contain label for each image having siz of :
#                (# of instances, grid_ row, grid_column, # of anchor_box, label_of_each_anchor_box) : (69, 8, 8, 2, 10)
#                label_of_each_anchor_box contain : [object mid_point_x relative to grid number,
#                                                    object mid_point_Y relative to grid number,
#                                                    object width i.e.: grid crossed on X-axis,
#                                                    object height i.e.: grid crossed on Y-axis,
#                                                    object presence in anchor box i.e.: anchor_confidence,
#                                                    class of object in one_hot_encoding ]

# true_boxes = contained all boxes present in image: an image maximum can identify 50 object of configuration [x, y, w, h] per image
#              having a shape of (69, 1, 1, 1, 50, 4)

# anchor_boxes = used to generate anchor Box using K_means algorithm : size (no_of_anchor_box, anchor_box_dimension) 
#                here anchor_box_dimension is 2 (width of anchor_box, height of anchor_box )    
# original_image_size =  list of touple of original image size of training images 
#                        ...will be helpful in resizing image after prediction



def create_train_set(path, file, image_folder, input_image_size, no_of_grid, no_of_class, no_of_anchor_box ):
    os.getcwd()

    os.chdir(path)
    os.getcwd()
    df = read_csv_file(file)
    image_list=df[['Image_name','Image_shape']].drop_duplicates()

    os.chdir(image_folder)
    
    
    ###############################
    image_rect_dict=[]
    i=0;
    total_instances=0
    no_of_instances = len(image_list['Image_name'])
    original_image_size =[]
    for img in image_list['Image_name']:
        
      
        orig_image= cv2.imread(img)
 
        image_shape=image_list.iloc[i]['Image_shape']
        image_shape=[int(item) for item in image_list.iloc[i]['Image_shape'][1:][:-1].split(",")]
        height = image_shape[0]
        width = image_shape[1]
        SHAPE = (height, width)
        original_image_size.append(SHAPE)
        #print("image.shape ",image_shape)
        i=i+1;
        rect_midpoint=[]
     
        
        rect_midpoint_index=df.index[df['Image_name'] == img].tolist()
    
        Image_info=[]
        for rect in rect_midpoint_index:
            rect_info=[ df.iloc[rect-1]['Top_left'] , df.iloc[rect-1]['Bottom_Right'], df.iloc[rect-1]['class']]
            Top_left=[int(item) for item in df.iloc[rect-1]['Top_left'][1:][:-1].split(",")]
            Bottom_Right=[int(item) for item in df.iloc[rect-1]['Bottom_Right'][1:][:-1].split(",")]
            
            Image_info.append([Top_left, Bottom_Right, df.iloc[rect-1]['class']])
        
    
        total_instances+=len(Image_info)
        image_rect_dict.append([img,[image_shape, Image_info]])

    #########################################
    #image rect printing before normalization
   # print("creating rectangled dataset")
   # image_rect_printing(image_folder, image_rect_dict)
#     
#     for image in image_rect_dict:
#         original_image_size.append(image[1][0])
#         print(image[1][0])
        
    Image_rect_dict = copy.deepcopy(image_rect_dict)
   # print("creating rectangled normalized dataset")
    normalized_image_rect_dict = normalizing_image(image_rect_dict, input_image_size)
    #########################################
    #image rect printing before normalization
    #image_norm_rect_printing(image_folder, normalized_image_rect_dict, input_image_size)
    #create_anchr_box()  #used to create anchor box configuration
#     print("before shuffling ----")
#     for image in normalized_image_rect_dict:
#         print("image_name = ",image[0] )
#     import random
#     random.shuffle(normalized_image_rect_dict)
#     print("after shuffling ----")
#     for image in normalized_image_rect_dict:
#         print("image_name = ",image[0] )
    #uncomment and run to generate anchore box
    anchor_boxes = create_anchor_box(normalized_image_rect_dict, no_of_anchor_box, no_of_grid, input_image_size)
    list_of_grid_corner, grid_size = create_grid(no_of_grid , input_image_size )
    
    instance_x, instance_y,true_boxes = map_each_object_t_grid(normalized_image_rect_dict, list_of_grid_corner, grid_size, no_of_class , no_of_anchor_box , input_image_size ,no_of_grid )

    return instance_x, instance_y, true_boxes, anchor_boxes, original_image_size 
    


# In[131]:


instance_x, instance_y, true_boxes, anchor_boxes,original_image_size = create_train_set(path = r'/home/bitnami/vikrant/deep_version/extraction_code', file = 'train_set.csv', image_folder = r'/home/bitnami/vikrant/deep_version/went_into_csv', input_image_size = (1024, 1024), no_of_grid = (8, 8), no_of_class = 5, no_of_anchor_box = 2 )
#print("instance_x.shape = ",instance_x.shape)
#print("instance_y.shape = ",instance_y.shape)
#print("true_boxes.shape = ",true_boxes.shape)

