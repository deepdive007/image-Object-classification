
# coding: utf-8

# In[1]:


import pandas as pd
import os, sys, csv
import glob, errno
import numpy as np
import cv2
import copy
import math


# In[24]:


#print(os.getcwd())


# In[21]:


def read_csv_file(filename):
    print(os.getcwd())
    csv_file=pd.read_csv(filename, header =None)
    df=pd.DataFrame(csv_file)
    df.columns=df.iloc[0]
   # print(df.columns)
    df=df.drop(df.index[0])
    return df


# In[23]:


#df = read_csv_file('train_set.csv')


# In[3]:


def normalizing_image(image_rect_dict, input_size):
    normal_height = input_size[0]
    normal_width = input_size[1]
    normalized_image_rect_dict=[]
    for document in image_rect_dict:
        
        image=document[0]
        image_info=document[1]
        shape_of_Doc = document[1][0]
        rect_info = document[1][1]
        x_factor=normal_width/(document[1][0][1])
        y_factor=normal_height/(document[1][0][0])
        document[1][0][0] = normal_height
        document[1][0][1] = normal_width
        for rect_instance_no in  range(len(document[1][1])):
            
            document[1][1][rect_instance_no][0][0] = document[1][1][rect_instance_no][0][0]*x_factor
            document[1][1][rect_instance_no][0][1] = document[1][1][rect_instance_no][0][1]*y_factor
            
            document[1][1][rect_instance_no][1][0] = document[1][1][rect_instance_no][1][0]*x_factor
            document[1][1][rect_instance_no][1][1] = document[1][1][rect_instance_no][1][1]*y_factor
            
        normalized_image_rect_dict.append(document)
    return normalized_image_rect_dict


# In[4]:


def create_grid(no_of_grid, input_image_size):
    size_of_grid = (int(input_image_size[0]/no_of_grid[0]), int(input_image_size[1]/no_of_grid[1] ))
    list_of_grid_corner=[]
    residual_length = input_image_size[0]
    #
    for row in range(no_of_grid[0]):
        bottom_right_y = 0
        if  residual_length >= size_of_grid[0]:
            bottom_right_y = size_of_grid[0] * (row + 1) 
        else:
            bottom_right_y = size_of_grid[0] * (row) + residual_length 
        
        residual_length = residual_length - size_of_grid[0]
        residual_width = input_image_size[1]
        row_grid=[]
        for col in range(no_of_grid[1]):
            bottom_right_x = 0
            if  residual_width >= size_of_grid[1]:
                bottom_right_x = size_of_grid[1] * (col + 1) 
            else:
                bottom_right_y = size_of_grid[1] * (col) + residual_width 
            residual_width = residual_width - size_of_grid[1]
            top_left_y = size_of_grid[0] * row
            top_left_x = size_of_grid[1] * col
            row_grid.append([(top_left_x, top_left_y), (bottom_right_x, bottom_right_y)])
        list_of_grid_corner.append(row_grid)
    return list_of_grid_corner, size_of_grid         
    


# In[5]:


def isinstance_in_grid(instance, grid):

    mid_point_x = (instance[0][0] + instance[1][0])/2
    mid_point_y = (instance[0][1] + instance[1][1])/2
    

    if (mid_point_x > grid[0][0] and mid_point_x <= grid[1][0]) and (mid_point_y > grid[0][1] and mid_point_y <= grid[1][1]):
        return True
    else:
        return False
    


# In[6]:


def identify_class(instance_class,no_of_class):
    #print("instance_class = ",instance_class)
    one_hot_class_vector= np.zeros((no_of_class,), dtype=int)
    class_list = ["heading", "paragraph", "table", "list", "image"]
    if instance_class != "":
        class_index = class_list.index(instance_class)
        one_hot_class_vector[class_index] = 1

    return one_hot_class_vector
    


# In[7]:


def create_label_for_grid(instance, flag, no_of_class, label_training_instance, grid_size):
    object_presence=0
    #print("instance = ",instance)
    label = np.zeros((5+no_of_class,), dtype = float)
    if flag == True and instance[4]!= "":
        object_presence = 1
#         rect_height = instance[1][0] - instance[0][0] 
#         rect_width =  instance[1][1] - instance[0][1]

#         b_x = (instance[0][0] + instance[1][0])/2
#         b_y = (instance[0][1] + instance[1][1])/2
#         b_h = rect_height/grid_size[0]
#         b_w = rect_width/grid_size[1]
        
        one_hot_class_vector = identify_class(instance[4], no_of_class)

        label[0] = instance[0]
        label[1] = instance[1]
        label[2] = instance[2]#width
        label[3] = instance[0]#height
        label[4] = object_presence
        label[5:] = one_hot_class_vector
    #else:
     #   label[1:] = None

    return label
        


# In[8]:


def interval_overlap(interval_a, interval_b):
    x1, x2 = interval_a
    x3, x4 = interval_b

    if x3 < x1:
        if x4 < x1:
            return 0
        else:
            return min(x2,x4) - x1
    else:
        if x2 < x3:
            return 0
        else:
            return min(x2,x4) - x3  


# In[9]:


def bbox_iou(box1, box2):
    x1_min  = box1[0] - box1[2]/2
    x1_max  = box1[0] + box1[2]/2
    y1_min  = box1[1] - box1[3]/2
    y1_max  = box1[1] + box1[3]/2
    
    x2_min  = box2[0] - box2[2]/2
    x2_max  = box2[0] + box2[2]/2
    y2_min  = box2[1] - box2[3]/2
    y2_max  = box2[1] + box2[3]/2
    
    intersect_w = interval_overlap([x1_min, x1_max], [x2_min, x2_max])
    intersect_h = interval_overlap([y1_min, y1_max], [y2_min, y2_max])
    
    intersect = intersect_w * intersect_h
    
    union = box1[2] * box1[3] + box2[2] * box2[3] - intersect
    
    return float(intersect) / union


# In[10]:


def calculate_iou_with_true_box(instance, anchor_w, anchor_h):
 #   print("instance_w = ",instance[0])
 #   print("instance_h = ",instance[1])
    #print("anchor_w, anchor_h = ",anchor_w, anchor_h)
    instance_cord = [0, 0, instance[0], instance[1]]
    anchor_cord = [0, 0, anchor_w, anchor_h]
    iou = bbox_iou(instance_cord, anchor_cord)
    return iou
    


# In[11]:


ANCHORS = [0.57273, 0.677385, 1.87446, 2.06253]
def find_best_anchor_box(instance):
    best_anchor = -1
    max_iou     = -1
  #  print("instance = ",instance)
   # print("len(ANCHORS) = ",len(ANCHORS))
    for i in range(len(ANCHORS)//2):
       # print("i ",i)
        anchor_w=ANCHORS[2*i]
        anchor_h=ANCHORS[2*i + 1]
    #    print("anchor_w, anchor_h = ",anchor_w, anchor_h)
        iou = calculate_iou_with_true_box(instance[2:4], anchor_w, anchor_h)
     #   print("iou = ",iou)
        if max_iou < iou:
            best_anchor = i
            max_iou= iou
    return best_anchor    
    


# In[12]:


def normalize_instance_relative_to_grid(no_of_grid, input_image_size, instance):
   # print("instance here = ",instance)
  #  print("no_of_grid = ",no_of_grid)
  #  print("input_image_size = ",input_image_size)
    center_x = 0.5*no_of_grid[1]*(instance[0][0] + instance[1][0])/input_image_size[1]
    center_y = 0.5*no_of_grid[0]*(instance[0][1] + instance[1][1])/input_image_size[0]
 #   print("center_x, center_y = ", center_x, center_y)
    center_w = no_of_grid[1]*abs(instance[0][0] - instance[1][0])/input_image_size[1]
    center_h = no_of_grid[0]*abs(instance[0][1] - instance[1][1])/input_image_size[0]
  #  print("center_w, center_h = ", center_w, center_h)
    box = [center_x, center_y, center_w, center_h, instance[2]]
    return box


# In[13]:


def map_each_object_t_grid(normalized_image_rect_dict, list_of_grid_corner, grid_size, no_of_class, no_of_anchor_box, input_image_size, no_of_grid ):
    label_training_set_Y = []
    label_training_set_X = []
    true_boxes = np.zeros((len(normalized_image_rect_dict),1, 1, 1, 50, 4 ))
  #  print("Len(no_of_instances) = ",len(normalized_image_rect_dict))

    for image_index in range(len(normalized_image_rect_dict)):
        image_name = cv2.imread(normalized_image_rect_dict[image_index][0])

        resize_image = cv2.resize(image_name, (input_image_size[1],input_image_size[0]))

        label_training_set_X.append(resize_image)
        true_box = []
  
        total_tru=0;
      #  print("no of instance in image =",len(normalized_image_rect_dict[image_index][1][1]))
        for instance in range(len(normalized_image_rect_dict[image_index][1][1])):
            Instance = normalized_image_rect_dict[image_index][1][1][instance]
            mid_point_x = (Instance[0][0] + Instance[1][0])/2
            mid_point_y = (Instance[0][1] + Instance[1][1])/2
        
            
            
        label_training_instance = []
       # print("size of list_of_grid_corner = ",len(list_of_grid_corner))
        for row_grid_list in list_of_grid_corner:
         #   print("row_grid_list++++++++++++++++++++++++++++++++++++++++++++++++++++")
            label_training_instance_row = []
            for grid in row_grid_list:
          #      print("grid____________________________________________________")
                label_list=[None]*no_of_anchor_box
                grid_label=[]
                true_content = 0
                for instance in range(len(normalized_image_rect_dict[image_index][1][1])):
                    flag = isinstance_in_grid(normalized_image_rect_dict[image_index][1][1][instance], grid)
                    if flag == True:
                     #   print("tru instance$$$$$$$$$$")
                        total_tru =total_tru+1
                        #############################instance is in grid, now find best suitable anchor box for it
                        normalized_instance = normalize_instance_relative_to_grid(no_of_grid, input_image_size, normalized_image_rect_dict[image_index][1][1][instance])
                       # print("unnormalized_instance = ",normalized_image_rect_dict[image_index][1][1][instance])
                        #print("normalized_instance = ",normalized_instance)
                        best_anchor_index = find_best_anchor_box(normalized_instance)
                       # print("best_anchor_index = ",best_anchor_index)
                        #print("true_contentbefor while",true_content)
                        #while true_content < no_of_anchor_box:
                        #print("true_content = ",true_content)
                        if label_list[best_anchor_index] is not None:
                            best_anchor_index=1-best_anchor_index
                     #   print("best_anchor_index = ",best_anchor_index)
                        if label_list[best_anchor_index] is None and true_content< no_of_anchor_box:
                              #  print("true")
                            label = create_label_for_grid(normalized_instance, flag, no_of_class, label_training_instance, grid_size)
                           # print("label = ",label)
                            label_list[best_anchor_index] = label
                            true_boxes[image_index,0,0,0,true_content] = label[:4] 
                            true_content = true_content + 1
                            #true_box.append(label[:4])
                            
                            #grid_label.append(label)
                        elif true_content < no_of_anchor_box:
                            
                           # print("best_anchor_index i else ",best_anchor_index)
                            zero_instance =[0,0,0,0,""] 
                            label = create_label_for_grid(zero_instance, flag, no_of_class, label_training_instance, grid_size)
                            #print("label = ",label)
                            label_list[best_anchor_index] = label
                            #grid_label.append(label)
                            true_content = true_content + 1
              # print("true_content before end while = ",true_content)
                zero_instance =[0,0,0,0,""] 
                label = create_label_for_grid(zero_instance, flag, no_of_class, label_training_instance, grid_size)
               # print("label = ",label)
               # print("label_list_before = ",label_list)
                for anchor_label in range(len(label_list)):
                    if label_list[anchor_label] is None:
                        label_list[anchor_label] = label
                    true_content = true_content + 1
                        #true_content = 0
                grid_label.append(list(label_list[0]))
                grid_label.append(list(label_list[1]))
                
               # print("label_list = ",list(label_list[0]))
               # print("label_list = ",list(label_list[1]))
                
                label_training_instance_row.append(grid_label)
                #print("new grid==============")
            label_training_instance.append(label_training_instance_row)
       # print("total_identified_rectanle in image ",normalized_image_rect_dict[image_index][0], total_tru)
      #  print("total_tru =",total_tru)
      #  print("image end&&&&&&&&&&&&&&&")
        label_training_set_Y.append(label_training_instance)
      #  true_boxes.append(true_box)
    instance_y = np.asarray(label_training_set_Y)                
    instance_x = np.asarray(label_training_set_X)
    return instance_x, instance_y, true_boxes
                        
#                         total_tru=total_tru+1
#                         true_content = true_content + 1
#                         label = create_label_for_grid(normalized_image_rect_dict[image_index][1][1][instance], flag, no_of_class, label_training_instance, grid_size)
#                         grid_label.append(label)
#                 while true_content<no_of_anchor_box:
#                     label = create_label_for_grid(None, False, no_of_class, label_training_instance, grid_size)
#                     grid_label.append(label)
#                     true_content = true_content + 1
#                 label_training_instance_row.append(grid_label)
#             label_training_instance.append(label_training_instance_row)
#        # print("total_identified_rectanle in image ",normalized_image_rect_dict[image_index][0], total_tru)
#         label_training_set_Y.append(label_training_instance)
#     instance_y = np.asarray(label_training_set_Y)
#     instance_x = np.asarray(label_training_set_X)
#     return instance_x, instance_y
        
    


# In[14]:


def create_train_set(path, file, image_folder, input_image_size, no_of_grid, no_of_class, no_of_anchor_box ):
    os.getcwd()
  #  path=r'D:\imagepro\deep_version\extraction_code'
    os.chdir(path)
    os.getcwd()
    df = read_csv_file(file)
    image_list=df[['Image_name','Image_shape']].drop_duplicates()
   # print( len(image_list), type(image_list))
   # image_folder=r'D:\imagepro\deep_version\rectangled_dataset\went_into_csv'
    os.chdir(image_folder)
    
    
    ###############################
    image_rect_dict=[]
    i=0;
    total_instances=0
    no_of_instances = len(image_list['Image_name'])
  
    for img in image_list['Image_name']:
    
      
        orig_image= cv2.imread(img)
       # print("orig_image.shape",orig_image.shape)
        image_shape=image_list.iloc[i]['Image_shape']
        image_shape=[int(item) for item in image_list.iloc[i]['Image_shape'][1:][:-1].split(",")]
       
        
        i=i+1;
        rect_midpoint=[]
     
        
        rect_midpoint_index=df.index[df['Image_name'] == img].tolist()
    
        Image_info=[]
        for rect in rect_midpoint_index:
            rect_info=[ df.iloc[rect-1]['Top_left'] , df.iloc[rect-1]['Bottom_Right'], df.iloc[rect-1]['class']]
            Top_left=[int(item) for item in df.iloc[rect-1]['Top_left'][1:][:-1].split(",")]
            Bottom_Right=[int(item) for item in df.iloc[rect-1]['Bottom_Right'][1:][:-1].split(",")]
            
            Image_info.append([Top_left, Bottom_Right, df.iloc[rect-1]['class']])
        
    
        total_instances+=len(Image_info)
        image_rect_dict.append([img,[image_shape, Image_info]])

    
    Image_rect_dict = copy.deepcopy(image_rect_dict)
    normalized_image_rect_dict = normalizing_image(image_rect_dict, input_image_size)
    list_of_grid_corner, grid_size = create_grid(no_of_grid , input_image_size )
    
    instance_x, instance_y,true_boxes = map_each_object_t_grid(normalized_image_rect_dict, list_of_grid_corner, grid_size, no_of_class , no_of_anchor_box , input_image_size ,no_of_grid )

    return instance_x, instance_y, true_boxes
    


# In[25]:


instance_x, instance_y, true_boxes = create_train_set(path = r'/home/bitnami/vikrant/deep_version/extraction_code', file = 'train_set.csv', image_folder = r'/home/bitnami/vikrant/deep_version/went_into_csv', input_image_size = (1024, 1024), no_of_grid = (8, 8), no_of_class = 5, no_of_anchor_box = 2 )
print("instance_x.shape = ",instance_x.shape)
print("instance_y.shape = ",instance_y.shape)
print("true_boxes.shape = ",true_boxes.shape)

